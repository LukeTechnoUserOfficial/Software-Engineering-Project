﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;

namespace News_App
{
    public partial class Form1 : Form
    {

        // API

        public String Client_ID = "3e3955b65e54416195986bc285a56b41";
        String ClientSecretCode = "d7dc286ccbd2496a96d91f4038f7829e";

        public String NewsKey = "db5f8db514fc496696159cb9697d2e87";
        public String SearchNewsURL = "https://newsapi.org/v2/top-headlines?country=gb&apiKey=";

        public string RequestNewsKey()
        {
            return NewsKey;
        }

        public string RequestSearchURL()
        {
            return SearchNewsURL;
        }

        public string Get(string uri)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                return reader.ReadToEnd();
            }
        }

        // Form Stuff

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Data = Get(RequestSearchURL() + RequestNewsKey());
            //Console.WriteLine(Data);

            dynamic stuff = JObject.Parse(Data);
            Console.WriteLine("Articles:");
            Console.WriteLine(stuff.articles);
            for (int x = 1; x <= stuff.articles.Count; x++)
            {
                listBox1.Items.Add(stuff.articles[x.ToString()].title);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
