﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Collections.Specialized;
using System.Net.Http;
using System.Net.Http.Headers;
using SpotifyAPI.Web;
using SpotifyAPI.Web.Auth;
using SpotifyAPI.Web.Models;

namespace News_App
{
    public partial class Form1 : Form
    {

        // API
        private static SpotifyWebAPI _spotify;
        string clientId = "3e3955b65e54416195986bc285a56b41";
        string clientSecret = "d7dc286ccbd2496a96d91f4038f7829e";
        
        public String NewsKey = "db5f8db514fc496696159cb9697d2e87";
        public String SearchNewsURL = "https://newsapi.org/v2/top-headlines?country=gb&apiKey=";

        public string RequestNewsKey()
        {
            return NewsKey;
        }

        public string RequestSearchURL()
        {
            return SearchNewsURL;
        }

        public string Get(string uri)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                return reader.ReadToEnd();
            }
        }

        // Form Stuff

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Data = Get(RequestSearchURL() + RequestNewsKey());

            dynamic stuff = JObject.Parse(Data);
            Console.WriteLine("Articles:");
            Console.WriteLine(stuff.articles);
            foreach (var Item in stuff.articles)
            {
                listBox1.Items.Add(Item.title);
            }
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            CredentialsAuth auth = new CredentialsAuth(clientId, clientSecret);
            Token token = await auth.GetToken();
            _spotify = new SpotifyWebAPI()
            {
                AccessToken = token.AccessToken,
                TokenType = token.TokenType
            };

            FullTrack track = _spotify.GetTrack("3Hvu1pq89D4R0lyPBoujSv");
            Console.WriteLine("Current Track: " + track.Name); //Yeay! We just printed a tracks name.
            string Search = textBox1.Text;
            SearchItem item = _spotify.SearchItems(Search, SpotifyAPI.Web.Enums.SearchType.Album | SpotifyAPI.Web.Enums.SearchType.Playlist);
            Console.WriteLine(item.Albums.Total);

        }


    }
}
