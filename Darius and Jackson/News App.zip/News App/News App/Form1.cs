﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace News_App
{
    public partial class Form1 : Form
    {
        private Login Login;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void f(object sender, EventArgs e)
        {

        }

        private void Acess_Application_Click(object sender, EventArgs e)
        {

        }

        private void Log_in_Click_1(object sender, EventArgs e)
        {
            Login = new Login();
            Login.Show();
           
        }
    }
}
